# viridisLite 0.4.0

## New features

* Add 3 more color maps: mako, rocket, and turbo. 

## Minor improvements and fixes

* Minor bug fixes and improvements here and there. 

---